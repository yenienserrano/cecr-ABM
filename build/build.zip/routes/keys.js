"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    database: {
        host: 'localhost',
        user: 'root',
        password: 'corsan12',
        database: "empleados_de_comercio"
    }
};
